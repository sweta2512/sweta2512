import React,{useState} from "react";

const User = () => {
    const [file, setFile] = useState('');
    console.log(file)
    const handleChange = (e)=>{
       // console.log('kdfhsh')
        console.log(e.target.files);
        setFile(URL.createObjectURL(e.target.files[0]))
    }
    return (
        <>
            <div>
                <h2>Add Image:</h2>
                <input type="file" onChange={handleChange} />
                <img src={file} style={{width:'200px'}} />
            </div>


        </>
    )

}

export default User;