const Services = {
     COUNTRY_LIST: 'http://localhost:8000/api/country',
     STATE_LIST: 'http://localhost:8000/api/state',
     CITY_LIST: 'http://localhost:8000/api/city',
     REGISTER_API: 'http://127.0.0.1:8000/api/user',
     LOGIN_API: 'http://127.0.0.1:8000/api/login',
     GET_TEST_USER_API: 'https://jsonplaceholder.typicode.com/posts',

}

export default Services;

