<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsertestController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('test',[UsertestController::class,'test']);
Route::get('/add_country_state_city',[UsertestController::class,'add_country_state_city_view']);
Route::post('/add_country_state_city',[UsertestController::class,'add_country_state_city'])->name('add_country_state_city');
Route::get('/add_country_state_city',[UsertestController::class,'get_country_id']);
Route::get('/add_country_state',[UsertestController::class,'showcity']);
Route::post('/add_country_state',[UsertestController::class,'add_country_state'])->name('add_country_state');
Route::get('/add_country_state',[UsertestController::class,'showStateId']);
Route::post('/add_country_city',[UsertestController::class,'addCity']);
