<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Register;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Country;
use App\Models\State;
use App\Models\City;

class UsertestController extends Controller
{
    function test()
    {
        $user = new Register;
        $user->name = 'username';
        $user->email = 'xyz@chetu.com';
        $user->password = Hash::make('sweta');
        $user->confirm_password = Hash::make('sweta');
        $user->gender = null;
        $user->food = 'food';
        $user->movie = 'movie';
        $user->save();
        $data =  Register::all();
        //  print_r($data);
        //die('djksslghsg');
        die($data);
    }
    public function add_country_state_city_view()
    {
        return view('addCountry');
    }
    public function add_country_state_city(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'country' => 'required',
                'country_id' => 'required|email',
            ]);
            if (Country::where('country_id',  $request->country_id)->exists()) {
                $msg = response()->json([
                    'status' => 'failed',
                    'msg' => 'Country Id already Exist..'
                ]);
            } else {
                $country = new Country;
                $country->name = $request->country;
                $country->country_id = $request->country_id;
                $country->save();
                $msg = response()->json([
                    'status' => 'Success',
                    'msg' => 'Country Added..'
                ]);
            }

            return redirect('add_country_state_city')->with(['msg' => $msg]);
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
    }
    public function get_country_id()
    {
        try {
            $data = Country::all();
            return view('addCountry')->with(['data' => $data]);
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
    }

    public function add_country_state(Request $request)
    {
        try {
            //return $request->all();
            $validator = Validator::make($request->all(), [
                'state' => 'required',
                'country_id' => 'required',
                'state_id' => 'required'
            ]);
            if (State::where('state_id',  $request->state_id)->exists()) {
                $msg = response()->json([
                    'status' => 'failed',
                    'msg' => 'State Id already Exist..'
                ]);
            } else {
                $state = new State;
                $state->name = $request->state;
                $state->country_id = $request->country_id;
                $state->state_id = $request->state_id;
                $state->save();
                $msg = response()->json([
                    'status' => 'Success',
                    'msg' => 'State Added..'
                ]);
            }
            return redirect('add_country_state_city')->with(['msg' => $msg]);
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
    }
    function showcity(){
        return view('addcity');
    }

    function showStateId(){
        try{
            $data = State::all();
            //return $data;
            return view('addcity')->with(['state' => $data]); 
        }catch(\Exception $e){
            echo $e->getMessage();
        }
    }
    function addCity(Request $request){
        try{
            //return $request->all();
            $validator = Validator::make($request->all(), [
                'city' => 'required',
                'state_id' => 'required'
            ]);
            if (City::where('name',  $request->city)->exists()) {
                $msg= response()->json([
                    'status' => 'failed',
                    'msg' => 'State Id already Exist..'
                ]);
            } else {
                $city = new City;
                $city->name = $request->city;
                $city->state_id = $request->state_id;
                $city->save();
                $msg = response()->json([
                    'status' => 'Success',
                    'msg' => 'State Added..'
                ]);
            }
            return redirect('add_country_state_city');
        }catch(\Exception $e){
            echo $e->getMessage();
        }
    }
}
