<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

    <style>
        .formfields {
            width: 500px;
        }

        .hide {
            margin: 0 0 10px 200px;
            border-radius: 12px;
        }
    </style>
</head>

<body>
    <!-- For City -->
    <div id="city" class="container-fluid">
        <div class="container formfields">
            <h5>Add City</h5>
            <form method="post" action="<?php echo e(url('/add_country_city')); ?>">
                <?php echo csrf_field(); ?>
                <label for="exampleFormControlInput1" class="form-label">State:</label>
                <select name="state_id" class="form-select">
                    <option>Select State..</option>
                    <?php if(count($state)>0): ?>
                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->state_id); ?>"><?php echo e($d->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </select><br />
                <label for="exampleFormControlInput1" class="form-label">City:</label>
                <input class="form-control" type="text" placeholder="City Name" name="city" /><br />
               
                <input type="submit" name="citysub" class="hide" />
            </form><br />

            <!-- <button type="button" class="hide" onClick="hideCity()">Close City</button> -->
        </div>

    </div>




</body>

</html><?php /**PATH D:\xampp7.4\htdocs\laravelapp\myapp\resources\views/addcity.blade.php ENDPATH**/ ?>