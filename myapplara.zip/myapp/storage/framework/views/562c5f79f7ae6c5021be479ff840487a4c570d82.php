<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

    <style>
        #country {
            display: none;
        }

        #state {
            display: none;
        }

        #city {
            display: none;
        }

        .formfields {
            width: 500px;
        }

        .hide {
            margin: 0 0 10px 200px;
            border-radius: 12px;
        }
    </style>
</head>

<body>

    <!-- <?php if(session()->has('message')): ?>
    <?php $__currentLoopData = $mgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p class="alert alert-success"><?php echo e($m('status')); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php endif; ?> -->
    <div class="container-fluid">
        <button type="button" id="add_country" onClick="ShowCountry()">Add Country</button>
        <button type="button" id="add_state" onClick="ShowState()">Add State</button>
        <button type="button" id="add_city" onClick="ShowCity()">Add City</button>

    </div>


    <!-- For Country -->
    <div id="country" class="container-fluid mb-3">
        <div class="container formfields">
            <h1>Add Country</h1>
            <form method="post" action="<?php echo e(route('add_country_state_city')); ?>">
                <?php echo csrf_field(); ?>
                <label for="exampleFormControlInput1" class="form-label">Country:</label>
                <input class="form-control" type="text" placeholder="Country Name" name="country" />
                <label for="exampleFormControlInput1" class="form-label">Id:</label>
                <input class="form-control" type="number" placeholder="Country Code" name="country_id" /><br />
                <input type="submit" name="submit" class="hide" />
            </form><br />
            <button type="button" class="hide" onClick="hideCountry()">Close Country</button>
        </div>

    </div>


    <!-- For State -->
    <div id="state" class="container-fluid">
        <div class="container formfields">
            <h5>Add State</h5>
            <form method="post" action="<?php echo e(route('add_country_state')); ?>">
                <?php echo csrf_field(); ?>
                <label for="exampleFormControlInput1" class="form-label">Country:</label>
                <select name="country_id" class="form-select">
                    <option>Select Country..</option>
                    <?php if(count($data)>0): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->country_id); ?>"><?php echo e($d->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select><br />
                <label for="exampleFormControlInput1" class="form-label">State:</label>
                <input class="form-control" type="text" placeholder="State Name" name="state" /><br />
                <label for="exampleFormControlInput1" class="form-label">Id:</label>
                <input class="form-control" type="number" placeholder="State Code" name="state_id" /><br />
                upload file:<input type="file" accept="image/*" name="image[]" id='img' onchange="uploadImg(event)">
                <input type="submit" name="state1" class="hide" />
            </form><br />
            <button type="button" class="hide" onClick="hideState()">Close State</button>
        </div>

    </div>



    <div>
        <!-- onChange="uploadImg(e)" -->
        <form>
            upload multiple file:<input type="file" accept="image/*" id='img' onchange="uploadmultipleImg(event)" multiple>
        </form>
            <div id='container'>
                <img id="preview"/>
                
    
    </div>

    <!-- <input type="file" accept="image/*" onchange="loadFile(event)">
    <img id="output" /> -->


    <!-- Js started here -->
    <!-- <script>
        var loadFile = function(event) {
            var output = document.getElementById('output');
            output.src = URL.createObjectURL(event.target.files[0]);
            output.onload = function() {
                URL.revokeObjectURL(output.src) // free memory
            }
        };
    </script> -->
    <script>

        //preview multiple image

        function uploadmultipleImg(event){

            let files = event.target.files;
            let ele = document.getElementById('container')
            ele.innerHTM='';
            console.log(files.length)
            console.log(ele)
            for(let i=0; i<files.length ;i++){
                let url =URL.createObjectURL(files[i]);
                //ele.appendChild('<img src=""/>');
                console.log(url)
                ele.innerHTML+="<img src='"+url+"' width='100px'/>"
            }

        }










        //Preview single image

        function uploadImg(event){
            let url =URL.createObjectURL(event.target.files[0]);
            console.log(url)
            let im= document.getElementById('preview');
            im.src=url;
            console.log(im)
        }
        




        //To show forms
        function ShowCountry() {
            document.getElementById('country').style.display = 'block';
        }

        function ShowState() {
            document.getElementById('state').style.display = 'block';
        }

        function ShowCity() {
            // document.getElementById('city').style.display = 'block';
            window.location.href = 'http://localhost:8000/add_country_state';
        }

        //To hide forms
        function hideCountry() {
            document.getElementById('country').style.display = 'none';
        }

        function hideState() {
            document.getElementById('state').style.display = 'none';
        }

        function hideCity() {
            document.getElementById('city').style.display = 'none';
        }
    </script>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH D:\xampp7.4\htdocs\laravelapp\myapp\resources\views/addCountry.blade.php ENDPATH**/ ?>