<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

    <style>
        .formfields {
            width: 500px;
        }

        .hide {
            margin: 0 0 10px 200px;
            border-radius: 12px;
        }
    </style>
</head>

<body>
    <!-- For City -->
    <div id="city" class="container-fluid">
        <div class="container formfields">
            <h5>Add City</h5>
            <form method="post" action="{{url('/add_country_city')}}">
                @csrf
                <label for="exampleFormControlInput1" class="form-label">State:</label>
                <select name="state_id" class="form-select">
                    <option>Select State..</option>
                    @if(count($state)>0)
                    @foreach($state as $d)
                    <option value="{{$d->state_id}}">{{$d->name}}</option>
                    @endforeach
                    @endif

                </select><br />
                <label for="exampleFormControlInput1" class="form-label">City:</label>
                <input class="form-control" type="text" placeholder="City Name" name="city" /><br />
               
                <input type="submit" name="citysub" class="hide" />
            </form><br />

            <!-- <button type="button" class="hide" onClick="hideCity()">Close City</button> -->
        </div>

    </div>




</body>

</html>